let isChecking = false;

document.getElementById("resumeFile").addEventListener("change", handleFileUpload);
document.getElementById("jobRole").addEventListener("change", handleJobRoleChange);
document.getElementById("darkMode").addEventListener("change", function () {
  document.body.classList.toggle("dark-mode");
});
function handleFileUpload(event) {
  const file = event.target.files[0];
  const resumeTextArea = document.getElementById("resumeText");
  const detailsDiv = document.getElementById("details");

  if (!file) return;

  if (file.type === "text/plain") {
    const reader = new FileReader();
    reader.onload = function (e) {
      resumeTextArea.value = e.target.result;
    };
    reader.onerror = function () {
      detailsDiv.innerHTML = "<p class='error'>Error reading file.</p>";
    };
    reader.readAsText(file);
  } else {
    detailsDiv.innerHTML = "<p class='error'>Please upload a text file (.txt).</p>";
  }
}

function handleJobRoleChange(event) {
  const role = event.target.value;
  const keywordsInput = document.getElementById("keywords");
  const keywordSets = {
    software_engineer: "python, java, javascript, sql, git, agile",
    data_scientist: "python, r, sql, machine learning, tensorflow, pandas",
    project_manager: "project management, agile, scrum, leadership, communication"
  };
  keywordsInput.value = keywordSets[role] || "";
}
function checkATS() {
  if (isChecking) return;
  isChecking = true;
  const resumeFile = document.getElementById("resumeFile").files[0];
  let resumeText = document.getElementById("resumeText").value.toLowerCase().trim();
  const keywordsInput = document.getElementById("keywords").value.toLowerCase().trim();
  const resultDiv = document.getElementById("score-result");
  const loadingDiv = document.getElementById("loading");
  const scoreText = document.getElementById("score-text");
  const detailsDiv = document.getElementById("details");
  const progressCircle = document.getElementById("progress-circle");
  if (!resumeText && !resumeFile) {
    detailsDiv.innerHTML = "<p class='error'>Please provide a resume (text or file).</p>";
    resultDiv.classList.remove("hidden");
    loadingDiv.classList.add("hidden");
    isChecking = false;
    return;
  }
  if (!keywordsInput) {
    detailsDiv.innerHTML = "<p class='error'>Please enter keywords.</p>";
    resultDiv.classList.remove("hidden");
    loadingDiv.classList.add("hidden");
    isChecking = false;
    return;
  }
  loadingDiv.classList.remove("hidden");
  resultDiv.classList.add("hidden");
  setTimeout(() => {
    const keywords = keywordsInput
      .split(",")
      .map(keyword => keyword.trim())
      .filter(keyword => keyword.length > 0);
    if (keywords.length === 0) {
      detailsDiv.innerHTML = "<p class='error'>Please enter valid keywords (comma-separated).</p>";
      resultDiv.classList.remove("hidden");
      loadingDiv.classList.add("hidden");
      isChecking = false;
      return;
    }
    let matched = 0;
    const matchedKeywords = [];
    keywords.forEach(keyword => {
      const regex = new RegExp(`\\b${keyword}\\b`, "i");
      if (regex.test(resumeText)) {
        matched++;
        matchedKeywords.push(keyword);
      }
    });
    const score = Math.round((matched / keywords.length) * 100);
    progressCircle.style.background = `conic-gradient(#007bff ${score * 3.6}deg, #e9ecef 0deg)`;
    scoreText.textContent = `${score}%`;
    let tips = "";
    if (score < 50) {
      tips = "Your resume may not pass ATS filters. Try adding more relevant keywords and aligning your skills with the job description.";
    } else if (score < 80) {
      tips = "Good start! Consider including additional keywords or emphasizing key skills to boost your score.";
    } else {
      tips = "Excellent! Your resume is highly compatible with ATS systems.";
    }
    detailsDiv.innerHTML = `
      <p>Matched ${matched} out of ${keywords.length} keywords.</p>
      ${matchedKeywords.length > 0 ? `<p class="matched-keywords">Found: ${matchedKeywords.join(", ")}</p>` : ""}
      <p class="tips">${tips}</p>
    `;
    resultDiv.classList.remove("hidden");
    loadingDiv.classList.add("hidden");
    document.getElementById("result").focus();
    isChecking = false;
  }, 1000);
}
function resetForm() {
  document.getElementById("resumeFile").value = "";
  document.getElementById("resumeText").value = "";
  document.getElementById("jobRole").value = "";
  document.getElementById("keywords").value = "";
  document.getElementById("score-result").classList.add("hidden");
  document.getElementById("loading").classList.add("hidden");
  document.getElementById("progress-circle").style.background = "conic-gradient(#007bff 0deg, #e9ecef 0deg)";
  document.getElementById("score-text").textContent = "";
  document.getElementById("details").innerHTML = "";
}
function exportResults() {
  const score = document.getElementById("score-text").textContent;
  const details = document.getElementById("details").innerText;
  const content = `ATS Resume Score Checker Results\n\nScore: ${score}\n\n${details}`;
  const blob = new Blob([content], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "ats_score_results.txt";
  a.click();
  URL.revokeObjectURL(url);
}